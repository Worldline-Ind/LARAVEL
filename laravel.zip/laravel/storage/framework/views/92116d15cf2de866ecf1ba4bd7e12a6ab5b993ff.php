<div id="worldline_embeded_popup"></div>

<script type="text/javascript"  src="https://www.paynimo.com/paynimocheckout/client/lib/jquery.min.js" ></script>
<script type="text/javascript" src="https://www.paynimo.com/Paynimocheckout/server/lib/checkout.js"></script>
<script type="text/javascript">
      
    $(document).ready(function() { 
        var configJson = { 
            'tarCall': false,
            'features': {
                'showPGResponseMsg': true,
                'enableNewWindowFlow' : true,
                'enableAbortResponse': true, 
                'enableExpressPay': <?php echo ($mer_array['enableExpressPay'] == 1) ? 'true' : 'false'; ?>,
                'enableInstrumentDeRegistration': <?php echo ($mer_array['enableInstrumentDeRegistration'] == 1) ? 'true' : 'false'; ?>,
                'enableMerTxnDetails': true,  
                'siDetailsAtMerchantEnd': <?php echo ($mer_array['enableSIDetailsAtMerchantEnd'] == 1) ? 'true' : 'false'; ?>,
                'enableSI': <?php echo ($mer_array['enableEmandate'] == 1) ? 'true' : 'false'; ?>,
                'hideSIDetails': <?php echo ($mer_array['hideSIConfirmation'] == 1) ? 'true' : 'false'; ?>,
                'enableDebitDay': <?php echo ($mer_array['enableDebitDay'] == 1) ? 'true' : 'false'; ?>,
                'expandSIDetails': <?php echo ($mer_array['expandSIDetails'] == 1) ? 'true' : 'false'; ?>,
                'enableTxnForNonSICards':  <?php echo ($mer_array['enableTxnForNonSICards'] == 1) ? 'true' : 'false'; ?>,
                'showSIConfirmation':  <?php echo ($mer_array['showSIConfirmation'] == 1) ? 'true' : 'false'; ?>,
                'showSIResponseMsg': <?php echo ($mer_array['showSIResponseMsg'] == 1) ? 'true' : 'false'; ?>,
            },
            'consumerData': {
                'deviceId': 'WEBSH2',	//possible values 'WEBSH1' or 'WEBSH2'
                    'token':'<?php echo e($payval['hash']); ?>',
                    'returnUrl': '/checkout',
                    'responseHandler': handleResponse,
                    'paymentMode': '<?php echo e($mer_array['paymentMode']); ?>',
                    'checkoutElement': '<?php echo e(($mer_array['embedPaymentGatewayOnPage'] == 1) ? '#worldline_embeded_popup' : ''); ?>',
                    'merchantLogoUrl': '<?php echo e($mer_array['logoURL']); ?>', //provided merchant logo will be displayed
                    'merchantId': '<?php echo e($payval['marchantId']); ?>',//<?php echo e($mer_array['merchantCode']); ?>

                    'currency': '<?php echo e($payval['currencycode']); ?>',
                    'consumerId': '<?php echo e($payval['consumerId']); ?>',
                    'consumerMobileNo': '<?php echo e($payval['mobileNumber']); ?>',
                    'consumerEmailId': '<?php echo e($payval['email']); ?>',
                    'txnId': '<?php echo e($payval['txnId']); ?>',   //Unique merchant transaction ID
                    'items': [{
                        'itemId': '<?php echo e($payval['schemecode']); ?>',
                        'amount': '<?php echo e($payval['amount']); ?>',
                        'comAmt': '0'
                    }],
                    'customStyle': {
                        'PRIMARY_COLOR_CODE': '<?php echo e($mer_array['primaryColor']); ?>',   //merchant primary color code
                        'SECONDARY_COLOR_CODE': '<?php echo e($mer_array['secondaryColor']); ?>',   //provide merchant's suitable color code
                        'BUTTON_COLOR_CODE_1': '<?php echo e($mer_array['buttonColor1']); ?>',   //merchant's button background color code
                        'BUTTON_COLOR_CODE_2': '<?php echo e($mer_array['buttonColor2']); ?>'   //provide merchant's suitable color code for button text
                    },
                    'accountNo': '<?php echo e($payval['accNo']); ?>',    //Pass this if accountNo is captured at merchant side for eMandate/eNACH
                    'accountHolderName': '<?php echo e($payval['accountName']); ?>',  //Pass this if accountHolderName is captured at merchant side for ICICI eMandate & eNACH registration this is mandatory field, if not passed from merchant Customer need to enter in Checkout UI.
                    'ifscCode': '<?php echo e($payval['ifscCode']); ?>',       //Pass this if ifscCode is captured at merchant side.
                    'accountType': '<?php echo e($payval['accountType']); ?>',   //Required for eNACH registration this is mandatory field
                    'debitStartDate': '<?php echo e($payval['debitStartDate']); ?>',
                    'debitEndDate': '<?php echo e($payval['debitEndDate']); ?>', 
                    'maxAmount': '<?php echo e($payval['maxAmount']); ?>', 
                    'amountType': '<?php echo e($payval['amountType']); ?>', 
                    'frequency': '<?php echo e($payval['frequency']); ?>',
                    'merchantMsg': '<?php echo e($mer_array['merchantMessage']); ?>',
                    'disclaimerMsg': '<?php echo e($mer_array['disclaimerMessage']); ?>',
                    'saveInstrument': '<?php echo e($mer_array['saveInstrument']); ?>',
                    <?php if(isset($mer_array['paymentModeOrder'])): ?>
                    'paymentModeOrder':  ['<?php echo str_replace(",", "','", $mer_array['paymentModeOrder']) ?>']
                    <?php endif; ?>
            }
           
            };
            console.log(configJson);
            $.pnCheckout(configJson);
            if(configJson.features.enableNewWindowFlow) {
                pnCheckoutShared.openNewWindow();
            }
            function handleResponse(res) {
            let stringResponse = res.stringResponse;
            };
        });
</script>

<?php /**PATH D:\laravel\laravel\resources\views/checkoutpage.blade.php ENDPATH**/ ?>