<?php 

//echo "<pre>";print_r($_POST);die();

	$data = array(
		'merchantCode'							=> $_POST['merchantCode'],
	    'merchantSchemeCode' 					=> $_POST['merchantSchemeCode'],
	    'salt'									=> $_POST['salt'],
	    'typeOfPayment' 						=> $_POST['typeOfPayment'],
	    'currency' 								=> $_POST['currency'],
	    'primaryColor' 							=> $_POST['primaryColor'],
	    'secondaryColor'						=> $_POST['secondaryColor'],
	    'buttonColor1' 							=> $_POST['buttonColor1'],
	    'buttonColor2' 							=> $_POST['buttonColor2'],
	    'logoURL'			 					=> $_POST['logoURL'],
	    'enableExpressPay' 						=> $_POST['enableExpressPay'],
	    'separateCardMode' 						=> $_POST['separateCardMode'],
	    'enableNewWindowFlow'		 			=> $_POST['enableNewWindowFlow'],
	    'merchantMessage' 						=> $_POST['merchantMessage'],
	    'disclaimerMessage' 					=> $_POST['disclaimerMessage'],
	    'paymentMode' 							=> $_POST['paymentMode'],
	    'paymentModeOrder' 						=> $_POST['paymentModeOrder'],
	    'enableInstrumentDeRegistration' 		=> $_POST['enableInstrumentDeRegistration'],
	    'transactionType'						=> $_POST['transactionType'],
	    'hideSavedInstruments' 					=> $_POST['hideSavedInstruments'],
	    'saveInstrument' 						=> $_POST['saveInstrument'],
	    'displayTransactionMessageOnPopup' 		=> $_POST['displayTransactionMessageOnPopup'],
	    'embedPaymentGatewayOnPage' 			=> $_POST['embedPaymentGatewayOnPage'],
	    'enableEmandate' 						=> $_POST['enableEmandate'],
	    'hideSIConfirmation'					=> $_POST['hideSIConfirmation'],
	    'expandSIDetails'						=> $_POST['expandSIDetails'],
	    'enableDebitDay'						=> $_POST['enableDebitDay'],
	    'showSIResponseMsg' 					=> $_POST['showSIResponseMsg'],
	    'showSIConfirmation'					=> $_POST['showSIConfirmation'],
	    'enableTxnForNonSICards' 				=> $_POST['enableTxnForNonSICards'],
	    'showAllModesWithSI' 					=> $_POST['showAllModesWithSI'],
	    'enableSIDetailsAtMerchantEnd' 			=> $_POST['enableSIDetailsAtMerchantEnd']
	);
    // $path = storage_path() . "/json/ingenico_AdminData.json";
    //     $mer_array = json_decode(file_get_contents($path), true); 

	$newData = json_encode($data);

	
    $path = storage_path() . "/json/ingenico_AdminData.json";
    //$path = $name.'.json';
	if(file_exists($path))
	{  
	    // echo 1;die();
	    unlink($path);
	    if(file_put_contents( ($path), $newData ) ) 
	    { 
	        //echo 'Admin Details updated successfully !!';
            return back();
	    }
	    else
	    { 
	        echo 'There is some error'; 
	    }
	}
	else
	{
		if(file_put_contents( ($path), $newData ) ) 
	    { 
	        //echo $file_name .' file created';
	       // $location = 'admin.php';
            return redirect("/admin");
	    } 
	    else
	    { 
	        echo 'There is some error'; 
	    }
	}	


?><?php /**PATH D:\xampp\htdocs\laravel\larainginico\resources\views/submit_request.blade.php ENDPATH**/ ?>