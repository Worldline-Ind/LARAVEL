<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Payment</title>
</head>
<body>
    <form action="/pay" method="post">
        <?php echo csrf_field(); ?>
        <div class="paydetail">
            <label>Merchant ID</label>
            <input type="text" name="marchantId" value="T3348">
        </div>
        <div class="paydetail">
            <label>SALT</label>
            <input type="text" name="salt" value="1496899267KMOWJE">
        </div>
        <div class="paydetail">
            <label>Transaction ID</label>
            <input type="text" name="txnId" value="<?php echo rand(100000000,1);?>">
        </div>
        <div class="paydetail">
            <label>Total Amount</label>
            <input type="text" name="amount" value="10.00">
        </div>
         <div class="paydetail">
            <label>Currency Code</label>
            <input type="text" name="currencycode" value="INR">
        </div>
        <div class="paydetail">
            <label>Scheme Code</label>
            <input type="text" name="schemecode" value="test">
        </div>
        <div class="paydetail">
            <label>Consumer ID</label>
            <input type="text" name="consumerId" value="c<?php echo rand(1000000,2);?>">
        </div>
        <div class="paydetail">
            <label>Mobile Number</label>
            <input type="text" name="mobileNumber" value="1234567890">
        </div>
        <div class="paydetail">
            <label>Email</label>
            <input type="text" name="email" value="demo@demo.com">
        </div>
        <div class="paydetail">
            <label>Customer Name</label>
            <input type="text" name="customerName" value="demo test">
        </div>
       <button type="submit">Pay Now</button>
        
    </form>
</body>
</html><?php /**PATH D:\larainginico\resources\views/paymentpage.blade.php ENDPATH**/ ?>