
<button id="checkout_confirmation">Make Payment</button>
<!--  -->

<script src="https://www.paynimo.com/paynimocheckout/client/lib/jquery.min.js" type="text/javascript"></script>
<script type="text/javascript" src="https://www.paynimo.com/Paynimocheckout/server/lib/checkout.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#checkout_confirmation').on('click', function(e) {
            e.preventDefault();
            var configJson = {
                'tarCall': false,
                'features': {
                    'showPGResponseMsg': true,
                    'enableAbortResponse': true,
                    'enableExpressPay': true,
                    'enableNewWindowFlow': true //for hybrid applications please disable this by passing false
                },
                'consumerData': {
                    'deviceId': 'WEBSH2',	//possible values 'WEBSH1' or 'WEBSH2'
                        'token':"<?php echo e($payval['hash']); ?>",
                        'returnUrl': '/checkout',
                        'responseHandler': handleResponse,
                        'paymentMode': 'all',
                        'merchantLogoUrl': 'https://www.paynimo.com/CompanyDocs/company-logo-md.png',  //provided merchant logo will be displayed
                        'merchantId': "<?php echo e($payval['marchantId']); ?>",
                        'currency': "<?php echo e($payval['currencycode']); ?>",
                        'consumerId': "<?php echo e($payval['consumerId']); ?>",
                        'consumerMobileNo': "<?php echo e($payval['mobileNumber']); ?>",
                        'consumerEmailId': "<?php echo e($payval['email']); ?>",
                        'txnId': "<?php echo e($payval['txnId']); ?>",   //Unique merchant transaction ID
                        'items': [{
                            'itemId': 'test',
                            'amount': "<?php echo e($payval['amount']); ?>",
                            'comAmt': '0'
                        }],
                        'customStyle': {
                            'PRIMARY_COLOR_CODE': '#3977b7',   //merchant primary color code
                            'SECONDARY_COLOR_CODE': '#FFFFFF',   //provide merchant's suitable color code
                            'BUTTON_COLOR_CODE_1': '#1969bb',   //merchant's button background color code
                            'BUTTON_COLOR_CODE_2': '#FFFFFF'   //provide merchant's suitable color code for button text
                        }
                    }
            };
            $.pnCheckout(configJson);
            if (configJson.features.enableNewWindowFlow) {
                pnCheckoutShared.openNewWindow();
            }

        });
        // action when payment popup is closed
        // $(".checkout-detail-box-inner .popup-close,.confirmBox .errBtnCancel").on("click", function() {
        //     window.location;
        // });
        function handleResponse(res) {
            let stringResponse = res.stringResponse;
            // if (typeof res != 'undefined' && typeof res.paymentMethod != 'undefined' && typeof res.paymentMethod.paymentTransaction != 'undefined' && typeof res.paymentMethod.paymentTransaction.statusCode != 'undefined' && res.paymentMethod.paymentTransaction.statusCode == '0300') {
            //     $("#response-string").val(stringResponse);
            //     $("#response-form").submit();
            // } else {
            //     $("#response-string").val(stringResponse);
            //     $("#response-form").submit();
            // }
        };

    });
</script><?php /**PATH D:\larainginico\resources\views/checkoutpage.blade.php ENDPATH**/ ?>