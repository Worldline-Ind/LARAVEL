<?php 

// if(isset($_GET['msg']))
// {
//     $msg = trim($_GET['msg']);
//     $msg_arr = explode("|", $msg);

//     $count = count($msg_arr);
//     $hash = $msg_arr[$count-1]; //Last hash value in pipe generated response

   
//     $path = storage_path() . "/json/ingenico_AdminData.json";
//     $mer_array = json_decode(file_get_contents($path), true); 

//     $updated_array = array_slice($msg_arr,0,$count-1,false);
//     $new_array = array_push($updated_array,$mer_array['salt']);
//     $updated_msg = implode("|", $updated_array);

//     $hashed = hash('sha512',$updated_msg); //Hash value of pipe generated response except last value

//     if($hash == $hashed)
//     {
//         echo $msg_arr[3].'|'.$msg_arr[5].'|1';
//     }
//     else
//     {
//         echo $msg_arr[3].'|'.$msg_arr[5].'|0';
//     }
// }
// else
// {
//     echo "ERROR !!! Invalid Input.";
// }
public function s2s(){
$path = storage_path() . "/json/ingenico_AdminData.json";
if(isset($_GET['msg'])){
    $msg = trim($_GET['msg']);
    $msg_arr = explode("|", $msg);
    $count = count($msg_arr);
    $hash = $msg_arr[$count-1]; //Last hash value in pipe generated response
    $mer_array = json_decode(file_get_contents($path), true);
    $updated_array = array_slice($msg_arr,0,$count-1,false);
    $new_array = array_push($updated_array,$mer_array['salt']);
    $updated_msg = implode("|", $updated_array);
    $hashed = hash('sha512',$updated_msg); //Hash value of pipe generated response except last value
    if($hash == $hashed)
    {
        echo $msg_arr[3].'|'.$msg_arr[5].'|1';
    }
    else
    {
        echo $msg_arr[3].'|'.$msg_arr[5].'|0';
    }
}
else
{
    echo "ERROR !!! Invalid Input.";
}
}

?><?php /**PATH D:\xampp\htdocs\laravel\larainginico\resources\views/s2s.blade.php ENDPATH**/ ?>